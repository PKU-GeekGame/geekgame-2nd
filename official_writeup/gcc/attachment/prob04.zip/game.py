from tempfile import NamedTemporaryFile
import subprocess
import os

def getflag(_):
    return 'fake{get real flag on the server}'

code_file = NamedTemporaryFile()

def handle_lv1():
    bin_file = NamedTemporaryFile()
    proc = subprocess.run(
        f'timeout 3s g++ -x c++ -o {bin_file.name} {code_file.name} >/dev/null 2>/dev/null',
        shell=True,
        stdin=subprocess.DEVNULL,
    )
    assert proc.returncode==0, 'failed to compile your code'
    
    size = os.stat(bin_file.name).st_size
    print(f'The executable has {size} bytes.')
    
    if size>8*1024*1024:
        print(getflag(1))
        
def handle_lv2():
    proc = subprocess.Popen(
        f'timeout 3s g++ -x c++ -o /dev/null {code_file.name}',
        shell=True,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    
    size = 0
    for chunk in iter(lambda: proc.stdout.read(65536), b''):
        size += len(chunk)
        if size>2*1024*1024:
            print(getflag(2))
            proc.kill()
            return
    
    print(f'The compiler output has {size} bytes.')
    
def handle_lv3():
    proc = subprocess.Popen(
        f'timeout 3s g++ -x c++ -o /dev/null {code_file.name}',
        shell=True,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    
    stdout, _ = proc.communicate()
    stdout = stdout.decode('utf-8', 'replace')
    
    assert proc.returncode!=0, 'compiler does not crash'
    
    lines = stdout.splitlines()
    if len(lines)>2 and lines[-2]=='Please include the complete backtrace with any bug report.':
        print(getflag(3))

print(f'''
We are using: {subprocess.check_output("g++ --version", shell=True).decode("utf-8")}
1: Let g++ output a huge file
2: Let g++ return a long compile error
3: Let g++ crash due to segment fault
''')
lv = int(input('Choose a level (1-3): '))

content = b''
print('\nWrite your C++ code below: (no more than 512 bytes, "//EOF" to stop)')
while True:
    line = input().encode('utf-8')
    if line==b'//EOF':
        break
    content += line+b'\n'
    assert len(content)<=512
code_file.write(content)
code_file.flush()
print('\nCompiling your code...')

if lv==1:
    handle_lv1()
elif lv==2:
    handle_lv2()
elif lv==3:
    handle_lv3()
else:
    print('Bad level!')
print('\nSee you later~')

