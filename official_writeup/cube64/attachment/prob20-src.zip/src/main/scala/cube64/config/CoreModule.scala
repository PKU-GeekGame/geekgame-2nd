package cube64.config

import chisel3._

abstract class CoreModule extends Module with HasCoreParams
