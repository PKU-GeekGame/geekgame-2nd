void wher3(int a);
void wr1te(int a, int b);
void p4int(int a);
void c1ear();
void m41n(int a)
{
    int b1 = 1;
    int b2 = 2;
    wher3(0x20);
    wr1te(0, 1);
    p4int(20);
    c1ear();
    return;
}
int main()
{
    return 1;
}