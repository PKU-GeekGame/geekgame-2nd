use std::convert::TryInto;

use seccompiler::{BpfProgram, Error, Result, SeccompAction, SeccompFilter, TargetArch};

pub fn init_sandbox() -> Result<()> {
    let bgf_program: BpfProgram = SeccompFilter::new(
        vec![
            (libc::SYS_write, vec![]),
            (libc::SYS_read, vec![]),
            (libc::SYS_sigaltstack, vec![]),
            (libc::SYS_futex, vec![]),
            (libc::SYS_exit_group, vec![]),
            (libc::SYS_rt_sigaction, vec![]),
            (libc::SYS_rt_sigreturn, vec![]),
        ]
        .into_iter()
        .collect(),
        SeccompAction::KillProcess,
        SeccompAction::Allow,
        TargetArch::x86_64,
    )
    .map_err(Error::Backend)?
    .try_into()
    .map_err(Error::Backend)?;
    seccompiler::apply_filter(&bgf_program)?;
    Ok(())
}

pub fn quick_exit() {
    unsafe { libc::_exit(0); }
}
