#! /usr/bin/env python3

import signal
import subprocess

def main():
    print('Running...')
    proc = subprocess.run(['/home/guest/saferust/target/release/saferust'])

    if proc.returncode == -signal.SIGSEGV:
        flag1 = open('/flag1', 'r').read().strip()
        print(f'Here is your flag 1: {flag1}')

    print('See you later~')

if __name__ == '__main__':
    main()
