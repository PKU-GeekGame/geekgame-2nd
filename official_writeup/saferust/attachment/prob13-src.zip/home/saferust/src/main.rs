use std::fs::File;

mod program;

fn main() {
    let _file = File::open("/flag2").unwrap();

    sandbox::init_sandbox().unwrap();

    program::run();

    sandbox::quick_exit();
}
