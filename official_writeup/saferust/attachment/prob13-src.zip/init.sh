#! /bin/sh

set -e

chmod 000 /mnt

su -c /home/guest/service.py guest

chmod 755 /mnt
cp /mnt/flag1 /flag1
cp /mnt/flag2 /flag2
chmod 000 /mnt

exec su -c /home/guest/check.py guest
