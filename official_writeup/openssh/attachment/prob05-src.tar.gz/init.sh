#! /bin/sh

set -e

cp /mnt/flag1 /flag1 && chmod 0400 /flag1 && chown admin1 /flag1
cp /mnt/flag2 /flag2 && chmod 0000 /flag2 && chown admin2 /flag2
chmod 000 /mnt

/sbin/sshd

su guest -c "yes '' | ssh-keygen -N '' > /dev/null"
su guest -c "cp ~/.ssh/id_rsa.pub ~/.ssh/authorized_keys"
exec su guest -c "ssh -o StrictHostKeyChecking=accept-new -tt guest@localhost"
