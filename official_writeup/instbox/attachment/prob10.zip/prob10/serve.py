import capstone
import subprocess
import base64


if __name__ == "__main__":
    code = input("code (in base64): ")
    code = base64.b64decode(code)

    inst_set = set()
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    md.skipdata = True
    for inst in md.disasm(code, 0):
        # print("0x%x+%d:\t%s\t%s" % (inst.address, inst.size, inst.mnemonic, inst.op_str))
        inst_set.add(inst.mnemonic)

    print(inst_set)
    assert len(inst_set) <= 1

    with open("a.bin", "wb") as f:
        f.write(code)
    subprocess.run(["./load", "a.bin"])
