#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("%s file\n", argv[0]);
    return 1;
  }
  char *file_name = argv[1];
  FILE *file = fopen(file_name, "rb");
  if (file == NULL) {
    printf("fopen fails\n");
    return 1;
  }
  const int BUF_SIZE = 512;
  char buf[BUF_SIZE];
  fread(buf, 1, BUF_SIZE, file);
  fclose(file);
  void *ptr = mmap(NULL, BUF_SIZE, PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (ptr == NULL) {
    printf("mmap fails\n");
    return 1;
  }
  memcpy(ptr, buf, BUF_SIZE);
  ((void(*)())ptr)();
  return 0;
}
