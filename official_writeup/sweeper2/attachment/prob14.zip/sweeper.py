#!/usr/bin/env python3

import random, os, time
from gorand import *


WIDTH = 16
HEIGHT = 16


def gen_board1():
    board = [[None] * WIDTH for _ in range(HEIGHT)]
    for i in range(HEIGHT):
        for j in range(WIDTH):
            board[i][j] = intn(257) % 2
    return board

def gen_board2():
    board = [[None] * WIDTH for _ in range(HEIGHT)]
    k = [uint64() for i in range(4)]
    for i in range(HEIGHT):
        for j in range(WIDTH):
            board[i][j] = (k[i//4]>>((i%4)*16+j))&1
    return board

def gen_board3():
    board = [[0] * WIDTH for _ in range(HEIGHT)]            
    for i in range(HEIGHT):
        secureVal=int.from_bytes(os.urandom(2),"big")
        if i==0 or i==15:
            secureVal=0
        elif i%2==0:
            secureVal&=0x5554
        else:
            secureVal&=0x2aaa
        for j in range(WIDTH):
            board[i][j] = ((secureVal<<j)&1) ^ (intn(257) % 2)
    return board


def check_win(board, marks):
    for i in range(HEIGHT):
        for j in range(WIDTH):
            if board[i][j] == 0 and not marks[i][j]:
                return False
    return True


def near_count(board, x, y):
    delta = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]
    count = 0
    for d in delta:
        tx, ty = x + d[0], y + d[1]
        if 0 <= tx < HEIGHT and 0 <= ty < WIDTH:
            count += board[tx][ty]
    return count


def show_board(board):
    for i in range(HEIGHT):
        for j in range(WIDTH):
            if board[i][j]:
                print("*", end='')
            else:
                print(near_count(board, i, j), end='')
        print()


def run(level):
    while True:
        board = [gen_board1, gen_board2, gen_board3][level-1]()
        marks = [[False] * WIDTH for _ in range(HEIGHT)]
        steps = 0
        print("New Game!")
        while not check_win(board, marks):
            x, y = input("> ").split()
            x, y = int(x), int(y)
            if board[x][y] != 0:
                print("BOOM!")
                show_board(board)
                break
            marks[x][y] = True
            print(near_count(board, x, y))
            steps += 1
        else: # win
            print("You win the game in %d steps!" % steps)
            print("flag{fake_"+str(level)+"}")
            break
        print()
        t = input("try again? (y/n)")
        if t != 'y':
            print("bye")
            break
    

if __name__ == "__main__":
    print("Welcome to the minesweeper game!")
    setseed(int(time.time()*1000))
    level = int(input("Level? "))
    if level==2:
        for i in range(uint64()%20221119+os.urandom(1)[0]):
            uint64()
    run(level)
